def sum_numbers(a, b):
    print("Sum result is : ",  (int(a) + int(b)))


def subtract_numbers(a, b):
    print("Subtract result is : ", (int(a) - int(b)))


def multiply_numbers(a, b):
    print("Multiply result is : ", (int(a) * int(b)))
